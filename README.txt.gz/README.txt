Author: Dr. Paul Harasti (NRL)
July 1, 2016.

The example IDL procedure 'display_nexrad_compz.pro'
reads in a 'XXXXyyyymmddhhmmss.txt' file and
displays the composite reflectivity.  The procedure expects
the input file "nexrad_compz.in" to contain the file name 
'XXXXyyyymmddhhmmss.txt' on its first line (see sample input file). 

To run, start IDL, then type 'display_nexrad_compz' at the IDL prompt.

